See: http://docs.missionpinball.org/en/latest/versions/release_notes.html

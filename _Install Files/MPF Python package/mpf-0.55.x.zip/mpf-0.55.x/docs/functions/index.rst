Common functions to use in your code
====================================

* :doc:`machine_variables`
* :doc:`player_variables`

.. toctree::
   :maxdepth: 1

   machine_variables
   player_variables

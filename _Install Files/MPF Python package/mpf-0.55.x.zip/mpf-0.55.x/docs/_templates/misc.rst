{name}
{module_underline}

.. autoclass:: {full_path_to_class}
   :members:
   :inherited-members:
   :show-inheritance:

   .. rubric:: Methods & Attributes

   The {name} has the following methods & attributes available. Note that methods & attributes inherited from
   the base class are not included here.

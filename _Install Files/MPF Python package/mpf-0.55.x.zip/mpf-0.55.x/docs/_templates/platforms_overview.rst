Hardware Platforms
==================

Hardware platforms are stored in a machine ``hardware_platforms`` dictionary, for example,
``self.machine.hardware_platforms['fast']`` or ``self.machine.hardware_platforms['p_roc']``.

.. toctree::

{platforms}
self.machine.{name}
{module_underline}

.. autoclass:: {full_path_to_class}
   :members:
   :show-inheritance:

   .. rubric:: Accessing the {name} in code

   There is only one instance of the {name} in MPF, and it's accessible via
   ``self.machine.{name}``.

   .. rubric:: Methods & Attributes

   The {name} has the following methods & attributes available. Note that methods & attributes inherited from
   base classes are not included here.
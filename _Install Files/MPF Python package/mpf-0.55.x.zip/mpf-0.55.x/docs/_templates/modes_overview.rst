Modes
=====

Covers all the "built-in" modes. They're accessible via ``self.machine.modes.*name*``, for example,
``self.machine.modes.game`` or ``self.machine.modes.base``.

.. toctree::

{modes}
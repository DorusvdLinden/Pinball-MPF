Overview & Tour of MPF code
===========================

This guide provides a general overview of the MPF and MPF-MC codebase.

.. toctree::

   files
   installation
   boot_process
   yaml
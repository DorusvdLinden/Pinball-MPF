goodbye (BCP command)
=====================

Lets one side tell the other than it’s shutting down.

Origin
------
Pin controller or media controller

Parameters
----------
None

Response
--------
None

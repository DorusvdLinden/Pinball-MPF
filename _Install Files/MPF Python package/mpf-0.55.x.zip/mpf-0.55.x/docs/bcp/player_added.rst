player_added (BCP command)
==========================

A player has just been added, with the player number passed via the *player_num* parameter.
Typically these commands only occur during Ball 1.

Origin
------
Pin controller

Parameters
----------

player_num
~~~~~~~~~~

Type: ``int``

The player number just added.

Response
--------
None

ball_end (BCP command)
======================

Indicates the ball has ended. Note that this does not necessarily mean that the next player’s
turn will start, as this player may have an extra ball which means they’ll shoot again.

Origin
------
Pin controller

Parameters
----------
None

Response
--------
None


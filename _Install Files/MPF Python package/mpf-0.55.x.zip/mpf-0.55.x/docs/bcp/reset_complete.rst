reset_complete (BCP command)
============================

This command notifies the pin controller that reset process is now complete. It *must* be sent in
response to receiving a :doc:`reset </bcp/reset>` command.

Origin
------
Media controller

Parameters
----------
None

Response
--------
None


"""Benchmarks for the MPF framework."""

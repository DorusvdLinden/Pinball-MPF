"""Module which contains all devices in MPF."""

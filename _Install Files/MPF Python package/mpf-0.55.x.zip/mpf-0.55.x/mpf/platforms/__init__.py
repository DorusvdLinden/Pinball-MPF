"""Hardware platforms in MPF."""

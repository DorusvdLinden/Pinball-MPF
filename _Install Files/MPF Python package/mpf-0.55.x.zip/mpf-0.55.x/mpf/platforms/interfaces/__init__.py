"""Package with interfaces for hardware platform devices."""

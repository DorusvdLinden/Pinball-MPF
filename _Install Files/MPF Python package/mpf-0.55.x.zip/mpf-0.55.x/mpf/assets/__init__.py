"""Contains modules which hold the asset base classes."""

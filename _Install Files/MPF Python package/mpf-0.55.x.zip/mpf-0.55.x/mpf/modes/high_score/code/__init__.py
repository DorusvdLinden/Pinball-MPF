"""Code of the default high score mode."""

"""Contains MPF default modes."""

"""Default attract mode."""

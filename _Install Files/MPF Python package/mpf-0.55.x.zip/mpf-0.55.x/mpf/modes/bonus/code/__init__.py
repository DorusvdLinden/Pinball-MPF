"""Code of the default bonus mode."""

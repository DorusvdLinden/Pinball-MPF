"""Default tilt mode."""

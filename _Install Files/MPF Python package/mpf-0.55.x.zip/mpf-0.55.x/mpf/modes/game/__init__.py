"""Default game mode."""

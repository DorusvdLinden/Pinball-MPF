"""Code of the default match mode."""

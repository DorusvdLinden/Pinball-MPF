"""Code of the default credits mode."""

"""Config players which can control devices based on hardware."""

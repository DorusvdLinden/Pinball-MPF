See: http://docs.missionpinball.org/en/dev/about/contributing_to_mpf.html

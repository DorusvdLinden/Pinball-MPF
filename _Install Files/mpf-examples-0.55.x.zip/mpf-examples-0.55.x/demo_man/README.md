# mpf_demo_man
MPF-based game code which runs on a 1994 Williams Demolition Man pinball machine

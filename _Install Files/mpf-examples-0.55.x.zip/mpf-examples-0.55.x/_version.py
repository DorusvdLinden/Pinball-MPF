"""Holds the version strings."""

version = '0.54.0'
mpf_version_required = '0.54'
